import { test, expect } from '@playwright/test';

test('The Black Jack Game', async({request}) =>{

    var deckID = '';
    const numOfPlayers = 2;
    const numOfCards = 2;

    await test.step("Verify API is up", async () => {
    const response = (await request.get('https://deckofcardsapi.com/api/deck/new/'));
    expect(response.status()).toBe(200);
    var cardsDeck = await response.json();
    deckID = cardsDeck.deck_id;
    });

    console.log('Deck ID:'+deckID);

    await test.step("Shuffle the deck", async () => {
    const response = (await request.get('https://deckofcardsapi.com/api/deck/'+deckID+'/shuffle/'));
    expect(response.status()).toBe(200);
    });

    for(var j=0; j<numOfCards; j++){

        for(var i=0; i<numOfPlayers; i++){
            await test.step("Draw card "+(j+1)+" and add it to Player"+(i+1), async () => {
            const response = (await request.get('https://deckofcardsapi.com/api/deck/'+deckID+'/draw/?count=1'));
            expect(response.status()).toBe(200);
            var cardPicked = await response.json();
            var cardPickedCode = cardPicked.cards[0].code;
            var cardPickedValue = cardPicked.cards[0].value;

            // console.log(cardPickedCode);
            // console.log(cardPickedValue);


            const response1 = (await request.get('https://deckofcardsapi.com/api/deck/'+deckID+'/pile/player'+(i+1)+'/add/?cards='+cardPickedCode));
            expect(response1.status()).toBe(200);

            });
        }
    }
    for(var i=1; i<=numOfPlayers; i++){
        await test.step("Check Player"+i+" has Blackjack", async () => {
        const response = (await request.get('https://deckofcardsapi.com/api/deck/'+deckID+'/pile/player'+i+'/list/'));
        expect(response.status()).toBe(200);
        var playerPile = await response.json();
        var total = 0;
        for(var c=0; c<numOfCards; c++){
            var card1 = playerPile["piles"]["player"+i]["cards"][c].value;
            // var card2 = playerPile["piles"]["player"+i]["cards"][1].code;

            // if(card1 == 'ACE'){
            //     total+=11;
            // } else if(card1 == ){

            // }

            switch (card1) {
                case 'ACE':
                    total+=11;
                    break;
                case 'KING':
                    total+=10;
                    break;
                case 'QUEEN':
                    total+=10;
                    break;
                case 'JACK':
                    total+=10;
                    break;
                case '10':
                    total+=10;
                    break;
                default:
                    total+=Number(card1);
            }

            console.log('Player'+i+':Card'+(c+1)+':'+card1);
            
        }

        console.log('Player'+i+' Total:'+total);

        if(total==21){
            console.log('HOORAYYYYYYYY! Player'+i+' has BLACKJACK!!!!');
        } else{
            console.log('Player'+i+' is not lucky to have blackjack.')
        }
        });
    }

})