import { test, expect } from '@playwright/test';

test('The Checker Game', async ({ page }) => {
    const orangeMoves = [
	{ initialCol: 6, initialRow: 2, finalCol: 5, finalRow: 1 },
   	{ initialCol: 7, initialRow: 1, finalCol: 6, finalRow: 2 },
    { initialCol: 8, initialRow: 2, finalCol: 7, finalRow: 1 },
    { initialCol: 6, initialRow: 6, finalCol: 5, finalRow: 7 },
    { initialCol: 6, initialRow: 4, finalCol: 4, finalRow: 6 },
    ];
    const messageField = page.locator('[id="message"]');

  await page.goto('https://www.gamesforthebrain.com/game/checkers/');
//   await page.pause();
  await page.waitForLoadState('load');

  await test.step("Verify Home page title", async () => {
      await expect(page).toHaveTitle('Checkers - Games for the Brain');
  });

  await test.step("Verify page is ready to start the play", async () => {
      await expect.soft(messageField).toHaveText("Select an orange piece to move.");
  });

  // console.log('Loop Length:'+orangeMoves.length);

  for(var i=0; i<orangeMoves.length ; i++ ){
    
      await test.step("Making move number:"+ (i+1), async () => {
            await page.locator('xpath=//*[@id="board"]/div['+orangeMoves[i].initialCol+']/img['+orangeMoves[i].initialRow+']').click();
            await page.waitForTimeout(3000); // Waits for 3 seconds
            await page.locator('xpath=//*[@id="board"]/div['+orangeMoves[i].finalCol+']/img['+orangeMoves[i].finalRow+']').click();
            await expect(messageField).toHaveText(/^(Make a move.|Click on your orange piece, then click where you want to move it.)$/,{timeout: 20000});
    });
    // console.log('i:'+(i+1));

  }

    await test.step("Click Restart link", async () => {
      await page.getByRole('link', { name: 'Restart...' }).click();
    });

    await test.step("Wait for page reload and verify the title", async () => {
        await page.waitForLoadState('load');
        await expect(page).toHaveTitle('Checkers - Games for the Brain')
    });

    await test.step("Verify page is ready to re-start the play", async () => {
        await expect.soft(page.locator('[id="message"]')).toHaveText("Select an orange piece to move.");
    });

});